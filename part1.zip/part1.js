
// array constructor and fill with random number
function getDiceRollArray(diceCount) {
    const newDiceRolls = new Array(diceCount).fill(0).map(() => {
        return Math.floor(Math.random() * 6) + 1
    })
    return newDiceRolls;
}

// get array constructor and do html to it 
function getDiceHtml(diceCount) {
    return getDiceRollArray(diceCount).map((num) => {
        return `<div class="dice">${num}</div>`;
    }).join('');
}

const hero = {
    elementId: "hero",
    nom: "Wizard",
    avatar: "images/wizard.png",
    health: 60,
    diceCount: 3
}

const monster = {
    elementId: "monster",
    nom: "Orc",
    avatar: "images/orc.png",
    health: 10,
    diceCount: 1
}


function renderCharacter(data) {
    // object destruction
    const { elementId, nom, avatar, health, diceCount, diceRoll } = data;
    // html random number
    const diceHtml = getDiceHtml(diceCount);

    document.getElementById(elementId).innerHTML =
        `<div class="character-card">
        <h4 class="name"> ${nom} </h4>
        <img class="avatar" src="${avatar}" />
        <div class="health">health: <b> ${health} </b></div>
        <div class="dice-container">    
        ${diceHtml}
        </div>
    </div>`;
}

renderCharacter(hero);
renderCharacter(monster);