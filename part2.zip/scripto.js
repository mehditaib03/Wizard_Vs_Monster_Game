import characterData from '/data.js'
import Character from '/character.js'


function dom() {
    document.getElementById('hero').innerHTML = wizard.getCharacterHtml();
    document.getElementById('monster').innerHTML = orc.getCharacterHtml();
}


// wizard.renderHtml();
const wizard = new Character(characterData.hero);
wizard.getCharacterHtml();


// orc.renderHtml();
const orc = new Character(characterData.monster);
orc.getCharacterHtml();

dom();