const characterData = {
    hero: {
        nom: "Wizard",
        avatar: "images/wizard.png",
        health: 60,
        diceCount: 3
    },

    monster: {
        nom: "Orc",
        avatar: "images/orc.png",
        health: 10,
        diceCount: 1
    }

}

export default characterData